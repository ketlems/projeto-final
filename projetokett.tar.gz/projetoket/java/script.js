function estrela1(){
    var star = document.getElementById('star');

     if (star.src.match('star.png')) {
        star.src="../img/star1.png"
    } 
    else {
       star.src="../img/star.png"
    }
}
function estrela2(){
    var star = document.getElementById('star2');

     if (star.src.match('star.png')) {
        star.src="../img/star1.png"
    } 
    else {
       star.src="../img/star.png"
    }
}
function estrela3(){
    var star = document.getElementById('star3');

     if (star.src.match('star.png')) {
        star.src="../img/star1.png"
    }
     else {
       star.src="../img/star.png"
    }
}
function estrela4(){
    var star = document.getElementById('star4');

     if (star.src.match('star.png')) {
        star.src="../img/star1.png"
    } 
    else {
       star.src="../img/star.png"
    }
}
function estrela5(){
    var star = document.getElementById('star5');

     if (star.src.match('star.png')) {
        star.src="../img/star1.png"
    } 
    else {
       star.src="../img/star.png"
    }
}
function estrela6(){
    var star = document.getElementById('star6');

     if (star.src.match('star.png')) {
        star.src="../img/star1.png"
    }
     else {
       star.src="../img/star.png"
    }
}
function estrela7(){
    var star = document.getElementById('star7');

     if (star.src.match('star.png')) {
        star.src="../img/star1.png"
    } 
    else {
       star.src="../img/star.png"
    }
}
function estrela8(){
    var star = document.getElementById('star8');

     if (star.src.match('star.png')) {
        star.src="../img/star1.png"
    } 
    else {
       star.src="../img/star.png"
    }
}