<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/style.css">
    <title>Biblioket</title>
</head>
<body>
    <nav class="total detalhes">
        <a href="#favoritos">favoritos</a>
        <a href="#lista"> minha lista </a>
        <a href="index.php"> home </a>
    </nav> 
        <section class="separacao">
            <div id="favoritos" class="favoritos"></div>
            <h2>favoritos</h2>
           <a href="https://www.amazon.com.br/Coisas-%C3%B3bvias-sobre-amor-2/dp/6559810119/ref=sr_1_1?crid=90ET3YGKN3KI&dib=eyJ2IjoiMSJ9.7IxCuhbW23YKWFd1iqAL-cNEStVfPsM5NMZE9fJ6I9lCHi2JmaCTBpt2byD4Him8M0sL8rL-tBSjGtZu3D6gv30Y0b8zfBkde0dDXEXewWRS9OvrCMJrMiFulDXGK3qElfrmMuX-RvcIW9skB4YJ-yWaq4II_RzprED7ENeleZy1osVouZ1149xAtPJM88Eiux71S5yl0ly2ofz8y3F0Rh_pygR4yjXaSJ6YILjV8Fo.GbJJf7WQkhESwG7lcgGC4Xbzy2Oz8eEmj9PKVjoNYZA&dib_tag=se&keywords=coisas+obvio+sobre+o+amor&qid=1726251224&s=books&sprefix=c%2Cstripbooks%2C380&sr=1-1"> <img src="img/9.jpg"></a>

           <a href="https://www.amazon.com.br/maldi%C3%A7%C3%A3o-prata-Maldi%C3%A7%C3%A3o-Prata-BRINDES/dp/6559815714/ref=sr_1_5?__mk_pt_BR=%C3%85M%C3%85%C5%BD%C3%95%C3%91&dib=eyJ2IjoiMSJ9.dHiWw_x_LehqHu-H-kmNa7TYB5x_-J7naCTDoQGVzkOiI-gClk1_aouzIbJiYxSpfqnjO592H3ut-DzwZGdy8bd7ueiRpXd3uXpLVG2MYuGHhxgkbdXVXlCB7NxCgtmGI6Tme0jUd8ihUvZDzrpxeFQIHa9njEtrW_Rr_pkb9hXwP4LRSELF7BtCUucjwZUM_8C24lxLjtxgwd_zKDdYwhtjG_5I9KG5W6Vse8U68tI.I0JM87Hvjk8oTMbC5OhTXaEY3hDKvPo5JrVeyvpJ_dM&dib_tag=se&keywords=pre+vendas&qid=1726255473&s=books&sr=1-5"><img src="img/21.jpg" ></a>

           <a href="https://www.amazon.com.br/Melhor-do-que-nos-filmes/dp/6555607289/ref=sr_1_1?crid=2B7EBVXTOCXFM&dib=eyJ2IjoiMSJ9.IEj8e7Jr5Qbj7xGT2bTWwF9wySphERLMKadXU4R7F-_SvK5o7mtjHB6z3ysAIq8Wxkc7QXvqi_s9jn2rPLkp29iacDCT5aE7zVHB_WlmXMP9LNlZ87zbOk32l9ceIjUrxzZRlqPOXuMlXSRDs2xH9v6SjCh_zgjJE1MeolcXT-4qzAiL_jX8V_0IDMcC45UoK0gYmU8ZlCJPGqtCH1ddGJS8PSGhlEHIRm6AopGzu0w.hgSTClVLv6arwHu3m8kAzynO76vS1Xw49oh2cXhicOk&dib_tag=se&keywords=%C3%A9+melhor+que+nos+filmes&qid=1726061812&s=books&sprefix=%2Cstripbooks%2C299&sr=1-1"><img src="img/2.jpg"></a>
        </section>

        <section class="separacao">
            <div id="lista" class="lista"></div>
            <h2>minha lista</h2>
            <a href="https://www.amazon.com.br/Coisas-%C3%B3bvias-sobre-amor-2/dp/6559810119/ref=sr_1_1?crid=90ET3YGKN3KI&dib=eyJ2IjoiMSJ9.7IxCuhbW23YKWFd1iqAL-cNEStVfPsM5NMZE9fJ6I9lCHi2JmaCTBpt2byD4Him8M0sL8rL-tBSjGtZu3D6gv30Y0b8zfBkde0dDXEXewWRS9OvrCMJrMiFulDXGK3qElfrmMuX-RvcIW9skB4YJ-yWaq4II_RzprED7ENeleZy1osVouZ1149xAtPJM88Eiux71S5yl0ly2ofz8y3F0Rh_pygR4yjXaSJ6YILjV8Fo.GbJJf7WQkhESwG7lcgGC4Xbzy2Oz8eEmj9PKVjoNYZA&dib_tag=se&keywords=coisas+obvio+sobre+o+amor&qid=1726251224&s=books&sprefix=c%2Cstripbooks%2C380&sr=1-1"> <img src="img/9.jpg"></a>
 
            <a href="https://www.amazon.com.br/maldi%C3%A7%C3%A3o-prata-Maldi%C3%A7%C3%A3o-Prata-BRINDES/dp/6559815714/ref=sr_1_5?__mk_pt_BR=%C3%85M%C3%85%C5%BD%C3%95%C3%91&dib=eyJ2IjoiMSJ9.dHiWw_x_LehqHu-H-kmNa7TYB5x_-J7naCTDoQGVzkOiI-gClk1_aouzIbJiYxSpfqnjO592H3ut-DzwZGdy8bd7ueiRpXd3uXpLVG2MYuGHhxgkbdXVXlCB7NxCgtmGI6Tme0jUd8ihUvZDzrpxeFQIHa9njEtrW_Rr_pkb9hXwP4LRSELF7BtCUucjwZUM_8C24lxLjtxgwd_zKDdYwhtjG_5I9KG5W6Vse8U68tI.I0JM87Hvjk8oTMbC5OhTXaEY3hDKvPo5JrVeyvpJ_dM&dib_tag=se&keywords=pre+vendas&qid=1726255473&s=books&sr=1-5"><img src="img/21.jpg" ></a>
 
            <a href="https://www.amazon.com.br/Melhor-do-que-nos-filmes/dp/6555607289/ref=sr_1_1?crid=2B7EBVXTOCXFM&dib=eyJ2IjoiMSJ9.IEj8e7Jr5Qbj7xGT2bTWwF9wySphERLMKadXU4R7F-_SvK5o7mtjHB6z3ysAIq8Wxkc7QXvqi_s9jn2rPLkp29iacDCT5aE7zVHB_WlmXMP9LNlZ87zbOk32l9ceIjUrxzZRlqPOXuMlXSRDs2xH9v6SjCh_zgjJE1MeolcXT-4qzAiL_jX8V_0IDMcC45UoK0gYmU8ZlCJPGqtCH1ddGJS8PSGhlEHIRm6AopGzu0w.hgSTClVLv6arwHu3m8kAzynO76vS1Xw49oh2cXhicOk&dib_tag=se&keywords=%C3%A9+melhor+que+nos+filmes&qid=1726061812&s=books&sprefix=%2Cstripbooks%2C299&sr=1-1"><img src="img/2.jpg"></a>
         </section>
</body>
</html>